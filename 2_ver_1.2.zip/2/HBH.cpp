#include "HBH.h"



void HBH::Nhap()
{
	for (int i = 0; i < soLuongDiem; i++)
	{
		dinh[i].Nhap();
	}
	if ((dinh[0].getY()-dinh[3].getY())!=(dinh[1].getY() - dinh[2].getY())||(dinh[0].getX() - dinh[1].getX())!= (dinh[3].getX() - dinh[2].getX()))
	{
		cout << "Day khong phai la Hinh Binh Hanh "<<endl;
		Nhap();
	}
	else
	{
		cout << "Day la hinh binh hanh"<<endl;
	}
}

HBH::HBH()
{
	soLuongDiem = 4;
	dinh = new DIEM[4];
}


HBH::~HBH()
{
}
