#pragma once
#include"DIEM.h"
class DAGIAC
{
protected:
	int soLuongDiem;
	DIEM * dinh;
public:
	virtual void Nhap(){}
	void Xuat();
	void TinhTien();
	DAGIAC();
	~DAGIAC();
};

