#pragma once
#include"DAGIAC.h"
class TUGIAC:public DAGIAC
{

public:
	void Nhap();
	void Xuat();
	void TinhTien();

	TUGIAC();
	~TUGIAC();
};

