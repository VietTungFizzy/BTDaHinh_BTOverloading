#include "HCN.h"



void HCN::Nhap()
{
	for (int i = 0; i < soLuongDiem; i++)
	{
		dinh[i].Nhap();
	}
	if ((dinh[0].getX() != dinh[3].getX()) || (dinh[1].getX() != dinh[2].getX()) || (dinh[0].getY() != dinh[1].getY()) || (dinh[2].getY() != dinh[3].getY()))
	{
		cout << "Day khog phai la hinh chu nhat"<<endl;
		Nhap();
	}
	else
	{
		cout << "Day la hinh chu nhat" << endl;
	}
}

HCN::HCN()
{
	soLuongDiem = 4;
	dinh = new DIEM[4];
}


HCN::~HCN()
{
}
