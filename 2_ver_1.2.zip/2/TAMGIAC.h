#pragma once
#include"DAGIAC.h"
class TAMGIAC:public DAGIAC
{
public:
	void Nhap();
	void Xuat();
	void TinhTien();
	TAMGIAC();
	~TAMGIAC();
};

