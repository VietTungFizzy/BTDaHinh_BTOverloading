#pragma once
#include "DAGIAC.h"
class HV :
	public DAGIAC
{
public:
	void Nhap();
	void Xuat() {}
	void TinhTien() {}
	HV();
	~HV();
};

