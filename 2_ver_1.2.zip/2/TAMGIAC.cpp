#include "TAMGIAC.h"



void TAMGIAC::Nhap()
{
	for (int i = 0; i < soLuongDiem; i++)
	{
		dinh[i].Nhap();
	}
}

void TAMGIAC::Xuat()
{
	for (int i = 0; i < soLuongDiem; i++)
	{
		cout << "Toa do dinh thu " << i << endl;
		dinh[i].Xuat();
	}
}

void TAMGIAC::TinhTien()
{
}

TAMGIAC::TAMGIAC()
{
	soLuongDiem = 3;
	dinh = new DIEM[3];
}


TAMGIAC::~TAMGIAC()
{
	delete[] dinh;
}
