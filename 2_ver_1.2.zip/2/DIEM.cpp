#include "DIEM.h"



void DIEM::Nhap()
{
	cout << "Nhap x: ";
	cin >> x;
	cout << "Nhap y: ";
	cin >> y;
}

void DIEM::Xuat()
{
	cout << "x= " << x << endl << "y= " << y << endl;
}

DIEM::DIEM()
{
	x = 0;
	y = 0;
}


DIEM::~DIEM()
{
}
