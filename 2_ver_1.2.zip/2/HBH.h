#pragma once
#include "DAGIAC.h"
class HBH :
	public DAGIAC
{

public:
	void Nhap();
	void Xuat();
	void TinhTien() {};
	HBH();
	~HBH();
};

