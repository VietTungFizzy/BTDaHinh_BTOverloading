#pragma once
#include "DAGIAC.h"
class HCN :
	public DAGIAC
{

public:
	void Nhap();
	void Xuat(){}
	void TinhTien(){}
	HCN();
	~HCN();
};

