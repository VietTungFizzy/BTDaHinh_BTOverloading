#include "HV.h"



void HV::Nhap()
{
	for (int i = 0; i < soLuongDiem; i++)
	{
		dinh[i].Nhap();
	}
	if ((dinh[0].getY() - dinh[3].getY()) != (dinh[1].getY() - dinh[2].getY()) 
		|| (dinh[0].getX() - dinh[1].getX()) != (dinh[3].getX() - dinh[2].getX())
		|| (dinh[0].getX()!=dinh[3].getX())
		|| (dinh[1].getX()!= dinh[2].getX()))
	{
		cout << "Day khong phai la hinh vuong"<<endl;
		Nhap();
	}
	else
	{
		cout << "Day la hinh vuong" << endl;
	}
}

HV::HV()
{
	soLuongDiem = 4;
	dinh = new DIEM[4];
}


HV::~HV()
{
}
