#include "DAGIAC.h"





void DAGIAC::Xuat()
{
	for (int i = 0; i < soLuongDiem; i++)
	{
		cout << "x[" << i + 1 << "]= " << dinh[i].getX() << endl;
		cout << "y[" << i + 1 << "]= " << dinh[i].getY() << endl;

	}
}

void DAGIAC::TinhTien()
{
	int dx, dy;
	cout << "Nhap dx: ";
	cin >> dx;
	cout << "Nhap dy: ";
	cin >> dy;
	for (int i = 0; i < soLuongDiem; i++)
	{
		dinh[i].set(dinh[i].getX() + dx, dinh[i].getY() + dy);
	}
}

DAGIAC::DAGIAC()
{
}


DAGIAC::~DAGIAC()
{
}
