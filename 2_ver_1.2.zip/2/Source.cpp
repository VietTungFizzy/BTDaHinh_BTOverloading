#include"TUGIAC.h"
#include"TAMGIAC.h"
#include"HBH.h"
#include"HCN.h"
#include"HV.h"
void main()
{
	DAGIAC * a;
	short check =-1;
	while (check <= 0 || check > 5)
	{
		cout << "Day la hinh gi? \n1.Tam giac \n2.Tu Giac \n3.Hinh binh hanh \n4.Hinh chu nhat \n5.Hinh vuong \nMoi ban chon: ";
		cin >> check;
		switch (check)
		{
		case 1:
			a = new TAMGIAC;
			a->Nhap();
			a->Xuat();
			a->TinhTien();
			a->Xuat();
			break;
		case 2:
			a = new TUGIAC;
			a->Nhap();
			a->Xuat();
			a->TinhTien();
			a->Xuat();
			break;
		case 3:
			a = new HBH;
			a->Nhap();
			a->Xuat();
			a->TinhTien();
			a->Xuat();
			break;
		case 4:
			a = new HCN;
			a->Nhap();
			a->Xuat();
			a->TinhTien();
			a->Xuat();
			break;
		case 5:
			a = new HV;
			a->Nhap();
			a->Xuat();
			a->TinhTien();
			a->Xuat();
			break;

		default:
			cout << "Sai du lieu\n";
			break;
		}
	}

	system("pause");
}