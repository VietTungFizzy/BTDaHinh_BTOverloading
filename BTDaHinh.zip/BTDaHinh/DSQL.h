#pragma once
#include"SACH.h"
#include"SGK.h"
#include"TAPCHI.h"
#include"TIEUTHUYET.h"
#include"TAILIEU.h"
class DSQL
{
	int soLuong;
	TAILIEU ** danhSach;
public:
	void Nhap();
	void Xuat();
	DSQL();
	~DSQL();
};

