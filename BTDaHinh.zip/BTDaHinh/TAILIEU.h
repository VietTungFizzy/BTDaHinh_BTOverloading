#pragma once
#include<iostream>
#include<string>
using namespace std;
class TAILIEU
{
protected:
	string ten, nhaXuatban;
	int soTrang;
public:
	virtual void Nhap();
	virtual void Xuat();

	void set(string ten, string nhaXuatBan, int soTrang) { this->ten = ten; this->nhaXuatban = nhaXuatBan; this->soTrang = soTrang; }
	TAILIEU();
	~TAILIEU();
};

