#include"DSQL.h"
void main()
{
	DSQL a;
	a.Nhap();
	a.Xuat();
	system("pause");
}