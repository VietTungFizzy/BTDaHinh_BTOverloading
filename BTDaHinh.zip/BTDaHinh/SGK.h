#pragma once
#include "TAILIEU.h"
class SGK :
	public TAILIEU
{
private:
	string mon;
public:
	void Nhap();
	void Xuat();

	void set(string mon) { this->mon = mon; }
	SGK();
	~SGK();
};

