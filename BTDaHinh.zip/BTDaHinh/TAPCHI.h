#pragma once
#include "TAILIEU.h"
class TAPCHI :
	public TAILIEU
{
	int so;
public:
	void Nhap();
	void Xuat();
	void set(int so) { this->so = so; }
	TAPCHI();
	~TAPCHI();
};

