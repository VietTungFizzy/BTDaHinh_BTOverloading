#include "DSQL.h"



void DSQL::Nhap()
{
	int	check;
	cout		<< "Nhap so luong sach: ";
	cin			>> soLuong;
	if (soLuong < 0)
	{
		cout << "Nhap sai du lieu moi nhap lai";
		Nhap();
	}
	danhSach	= new TAILIEU*[soLuong];
	for (int i = 0; i < soLuong; i++)
	{
		cout << "Chon 1 trong 4 loai sach: \n1.Sach \n2.Sach giao khoa \n3.Tap chi \n4.Tieu thuyet \nBan chon: ";
		cin >> check;
		switch (check)
		{
		case 1:
			danhSach[i] = new SACH;
			break;
		case 2:
			danhSach[i] = new SGK;
			break;
		case 3:
			danhSach[i] = new TAPCHI;
			break;
		case 4:
			danhSach[i] = new TIEUTHUYET;
			break;

		default:
			cout << "Nhap sai du lieu moi nhap lai";
			Nhap();
			break;
		}
		cin.ignore();
		danhSach[i]->Nhap();
	}
}

void DSQL::Xuat()
{
	for (int i = 0; i < soLuong; i++)
	{
		danhSach[i]->Xuat();
	}
}

DSQL::DSQL()
{
	soLuong = 0;
	this->danhSach = NULL;
}


DSQL::~DSQL()
{
	delete[] danhSach;
}
