#include "SGK.h"



void SGK::Nhap()
{
	string _mon;
	TAILIEU::Nhap();
	fflush(stdin);
	cout << "Nhap mon: ";
	getline(cin, _mon);
	set(_mon);
}

void SGK::Xuat()
{
	TAILIEU::Xuat();
	cout << "Mon: " << mon << endl;
}

SGK::SGK()
{
	this->mon = "";
}


SGK::~SGK()
{
}
