#include "TAILIEU.h"



void TAILIEU::Nhap()
{
	string _ten, _nhaXuatBan;
	int _soTrang;
	fflush(stdin);
	cout << "Nhap ten: ";
	getline(cin, _ten);
	fflush(stdin);
	cout << "Nhap ten nha xuat ban: ";
	getline(cin, _nhaXuatBan);
	cout << "Nhap so trang: ";
	cin >> _soTrang;
	if (_soTrang <= 0)
	{
		cout << "Nhap sai du lieu du lieu";
		cin.ignore();
		Nhap();
	}
	else
	{
		set(_ten, _nhaXuatBan, _soTrang);
	}
}

void TAILIEU::Xuat()
{
	cout << "Ten: " << ten << endl;
	cout << "Nha xuat ban: " << nhaXuatban << endl;
	cout << "So trang: " << soTrang << endl;

}

TAILIEU::TAILIEU()
{
	this->ten = "";
	this->nhaXuatban = "";
	this->soTrang = 0;
}


TAILIEU::~TAILIEU()
{
}
