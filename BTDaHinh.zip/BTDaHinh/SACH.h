#pragma once
#include "TAILIEU.h"
class SACH :
	public TAILIEU
{
protected: 
	string tacGia;
public:
	void Nhap();
	void Xuat();

	void set(string tacGia) { this->tacGia = tacGia; }
	SACH();
	~SACH();
};

