#include "TAPCHI.h"



void TAPCHI::Nhap()
{
	TAILIEU::Nhap();
	cout << "Nhap so: ";
	int _so;
	cin >> _so;
	if (_so < 0)
	{
		cout << "Nhap sai du lieu du lieu";
		cin.ignore();
		Nhap();
	}
}

void TAPCHI::Xuat()
{
	TAILIEU::Xuat();
	cout << "So: " << so << endl;
}

TAPCHI::TAPCHI()
{
	this->so = 0;
}


TAPCHI::~TAPCHI()
{
}
