#include "TIEUTHUYET.h"
void TIEUTHUYET::Nhap()
{
	SACH::Nhap();
	fflush(stdin);
	cout << "Nhap the loai: ";
	getline(cin, theLoai);
}

void TIEUTHUYET::Xuat()
{
	SACH::Xuat();
	cout << "The loai: " << theLoai << endl;
}


TIEUTHUYET::TIEUTHUYET()
{
	theLoai = "";
}


TIEUTHUYET::~TIEUTHUYET()
{
}
