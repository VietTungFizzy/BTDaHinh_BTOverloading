#include "SACH.h"



void SACH::Nhap()
{
	string _tacGia;
	TAILIEU::Nhap();
	fflush(stdin);
	cout << "Nhap ten tac gia: ";
	getline(cin, _tacGia);
	set(_tacGia);
}

void SACH::Xuat()
{
	TAILIEU::Xuat();
	cout << "Tac gia: " << tacGia << endl;
}

SACH::SACH()
{
	this->tacGia = "";
}


SACH::~SACH()
{
}
