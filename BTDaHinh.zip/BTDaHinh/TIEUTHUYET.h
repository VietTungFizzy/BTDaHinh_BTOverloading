#pragma once
#include "TAILIEU.h"
#include"SACH.h"
class TIEUTHUYET :
	public SACH
{
	string theLoai;
public:
	void Nhap();
	void Xuat();

	void set(string theLoai) { this->theLoai = theLoai; }
	TIEUTHUYET();
	~TIEUTHUYET();
};

