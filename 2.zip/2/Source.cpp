#include"TUGIAC.h"
void main()
{
	DAGIAC * a;
	a = new TUGIAC;
	a->Nhap();
	a->Xuat();
	a->TinhTien();
	a->Xuat();

	system("pause");
}