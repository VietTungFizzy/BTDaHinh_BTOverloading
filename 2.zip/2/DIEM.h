#pragma once
#include<iostream>
using namespace std;

class DIEM
{
	int x, y;
public:
	void Nhap();
	void Xuat();

	int getX() { return x; }
	int getY() { return y; }
	void set(int x, int y) { this->x = x; this->y = y; }
	DIEM();
	~DIEM();
};

