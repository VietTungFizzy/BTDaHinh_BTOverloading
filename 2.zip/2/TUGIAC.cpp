#include "TUGIAC.h"



void TUGIAC::Nhap()
{
	for (int i = 0; i < soLuongDiem; i++)
	{
		dinh[i].Nhap();
	}

}

void TUGIAC::Xuat()
{
	for (int i = 0; i < soLuongDiem; i++)
	{
		cout << "Toa do dinh thu " << i << endl;
		dinh[i].Xuat();
	}
}

void TUGIAC::TinhTien()
{
}

TUGIAC::TUGIAC()
{
	soLuongDiem = 4;
	dinh = new DIEM[4];
}


TUGIAC::~TUGIAC()
{
	delete[] dinh;
}
