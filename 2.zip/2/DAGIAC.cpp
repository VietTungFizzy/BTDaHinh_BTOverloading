#include "DAGIAC.h"





void DAGIAC::TinhTien()
{
	int dx, dy;
	cout << "Nhap dx: ";
	cin >> dx;
	cout << "Nhap dy: ";
	cin >> dy;
	for (int i = 0; i < soLuongDiem; i++)
	{
		dinh[i].set(dinh[i].getX() + dx, dinh[i].getY() + dy);
	}
}

DAGIAC::DAGIAC()
{
}


DAGIAC::~DAGIAC()
{
}
